data:extend({

 {
    type = "item",
    name = "aquifer-drill",
    icon = "__AquiferDrill__/graphics/icons/aquifer-drill.png",
    flags = { "goes-to-quickbar" },
    subgroup = "extraction-machine",
    place_result = "aquifer-drill",
    stack_size = 20,
  }

})