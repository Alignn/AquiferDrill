require("prototypes.item")
require("prototypes.recipe")
require("prototypes.entity.aquifer-drill")
require("prototypes.categories.recipe-category")